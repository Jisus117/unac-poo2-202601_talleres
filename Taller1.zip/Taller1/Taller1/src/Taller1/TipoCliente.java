package Taller1;

public enum TipoCliente {
    VIP,
    REGULAR,
    NORMAL
}
