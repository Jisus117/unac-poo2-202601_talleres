package Taller1;

public class NotificacionService {

    public void enviarConfirmacion(Pedido pedido) {
        System.out.println("Enviando confirmación al cliente");
    }
}
