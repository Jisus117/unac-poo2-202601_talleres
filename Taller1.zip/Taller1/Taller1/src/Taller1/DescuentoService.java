package Taller1;

public class DescuentoService {

    public double calcularTotal(Pedido pedido) {

        switch (pedido.getCliente()) {

            case VIP:
                return pedido.getTotal() * 0.8;

            case REGULAR:
                return pedido.getTotal() * 0.95;

            default:
                return pedido.getTotal();
        }
    }
}
