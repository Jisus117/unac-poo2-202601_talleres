package Taller1;

public class Pedido {

    private TipoCliente cliente;
    private double total;

    public Pedido(TipoCliente cliente, double total) {
        this.cliente = cliente;
        this.total = total;
    }

    public TipoCliente getCliente() {
        return cliente;
    }

    public double getTotal() {
        return total;
    }
}
