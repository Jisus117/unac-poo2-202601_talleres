package Taller1;

public class Main {
    public static void main(String[] args) {

        Pedido pedido = new Pedido(TipoCliente.VIP, 100);

        DescuentoService descuentoService = new DescuentoService();
        PedidoRepository repository = new PedidoRepository();
        NotificacionService notificacion = new NotificacionService();

        double totalFinal = descuentoService.calcularTotal(pedido);

        System.out.println("Total con descuento: " + totalFinal);

        repository.guardar(pedido);
        notificacion.enviarConfirmacion(pedido);
    }
}
