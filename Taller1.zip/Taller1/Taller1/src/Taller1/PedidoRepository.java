package Taller1;

public class PedidoRepository {

    public void guardar(Pedido pedido) {
        System.out.println("Guardando pedido en base de datos");
    }
}
